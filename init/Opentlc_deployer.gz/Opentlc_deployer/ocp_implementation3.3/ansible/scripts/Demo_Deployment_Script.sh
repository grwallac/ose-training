echo "Currently no Demo script available" >> /root/.NO_DEMO_SCRIPT
